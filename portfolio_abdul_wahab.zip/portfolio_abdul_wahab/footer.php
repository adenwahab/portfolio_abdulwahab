<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong>
                <span><a href="https://instagram.com/adennwahab?igshid=ZDdkNTZiNTM=">AbdulWahab_2023</a></span>
            </strong>
        </div>
    </div>
</footer>